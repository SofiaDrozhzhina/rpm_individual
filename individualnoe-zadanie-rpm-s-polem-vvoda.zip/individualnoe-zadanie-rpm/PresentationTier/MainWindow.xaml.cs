﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataTier;
using LogicTier;
using Microsoft.Win32;

namespace PresentationTier;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    private Магазин магазин;
    public MainWindow()
    {
        InitializeComponent();
        
    }

    private void btn_open_file_Click(object sender, RoutedEventArgs e)
    {
        List<Товар> товарыИзФайла = ВсеТовары.ПолучитьВсеТоварыИзФайла();

        if (товарыИзФайла.Count == 0)
        {
            MessageBox.Show("Нет товаров в файле!");
            return;
        }

        List<ТоварнаяПозиация> позиции = new List<ТоварнаяПозиация>();
        foreach (var t in товарыИзФайла)
        {
            позиции.Add(new ТоварнаяПозиация(t));
        }

        магазин = new Магазин(позиции);
        this.DataContext = магазин;
    }
    private string selectedFilePath;
    private void btn_save_to_file_Click(object sender, RoutedEventArgs e)
    {
        Microsoft.Win32.SaveFileDialog saveFileDialog = new Microsoft.Win32.SaveFileDialog();
        saveFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
        saveFileDialog.Title = "Выберите файл для сохранения";

        if (saveFileDialog.ShowDialog() == true)
        {
            selectedFilePath = saveFileDialog.FileName;
            MessageBox.Show($"Файл выбран: {selectedFilePath}");
        }
        string Транспорт = myComboBox.Text;
        string ПунктОтправки = PO.Text;
        string ПунктНазначения = PN.Text;
        string СтоимостьБилета = SB.Text;

        // Проверяем, что все поля заполнены
        if (string.IsNullOrWhiteSpace(Транспорт) ||
            string.IsNullOrWhiteSpace(ПунктОтправки) ||
            string.IsNullOrWhiteSpace(ПунктНазначения) ||
            string.IsNullOrWhiteSpace(СтоимостьБилета))
        {
            MessageBox.Show("Пожалуйста, заполните все поля.");
            return;
        }
        string строкаДляЗаписи = $"{Транспорт}*{ПунктОтправки}*{ПунктНазначения}*{СтоимостьБилета}";

        File.AppendAllText(selectedFilePath, строкаДляЗаписи + Environment.NewLine);

        MessageBox.Show("Рейс успешно сохранен!");

        myComboBox.SelectedIndex = -1;
        PO.Clear();
        PN.Clear();
        SB.Clear();
    }
    private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (myComboBox.SelectedItem != null)
        {
            var selectedItem = (System.Windows.Controls.ComboBoxItem)myComboBox.SelectedItem;
            MessageBox.Show($"Выбрано: {selectedItem.Content}");
        }
    }
}



