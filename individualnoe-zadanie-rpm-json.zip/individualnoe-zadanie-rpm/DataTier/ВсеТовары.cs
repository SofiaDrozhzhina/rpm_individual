﻿using System.Collections.ObjectModel;
using System.IO;
using System.Text.Json;
using System.Windows;

namespace DataTier
{
    public class ВсеТовары
    {
        public ObservableCollection<Товар> СписокТоваров { get; set; }

        public ВсеТовары()
        {
            СписокТоваров = new ObservableCollection<Товар>();
        }

        public void ЗагрузитьИзФайла(string путь)
        {
            if (File.Exists(путь))
            {
                string json = File.ReadAllText(путь);
                var товары = JsonSerializer.Deserialize<List<Товар>>(json);
                if (товары != null)
                {
                    СписокТоваров = new ObservableCollection<Товар>(товары);  // Преобразуем в ObservableCollection
                }
            }
        }
        public void СохранитьВФайл(string путь)
        {
            string json = JsonSerializer.Serialize(СписокТоваров, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(путь, json);
            MessageBox.Show("Данные сохранены в файл " + путь);
        }
    }
}
