﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace DataTier
{
    public class ВсеТовары
    {
        public static void СохранитьВсеТовары(List<Товар> товары)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "Текстовый файл (*.txt)|*.txt",
                Title = "Сохранить товары"
            };

            if (saveFileDialog.ShowDialog() == true)
            {
                using (StreamWriter writer = new StreamWriter(saveFileDialog.FileName, false, Encoding.UTF8))
                {
                    foreach (var товар in товары)
                    {
                        string line = $"{товар.Транспорт}*{товар.ПунктОтправки}*{товар.ПунктНазначения}*{товар.СтоимостьБилета}";
                        writer.WriteLine(line);
                    }
                }

                MessageBox.Show("Файл успешно сохранён.", "Сохранение");
            }
        }
        public static List<Товар> ПолучитьВсеТоварыИзФайла()
        {
            List<Товар> list = new List<Товар>();

            OpenFileDialog openFileDialog = new OpenFileDialog();

            if (openFileDialog.ShowDialog() == true)
            {
                string FilePath = openFileDialog.FileName;
                using (StreamReader sreader = new StreamReader(FilePath, Encoding.UTF8))
                {
                    while (!sreader.EndOfStream) // пока не конец потока

                    {
                        string[] line = sreader.ReadLine().Split("*");
                        
                        Товар tovar = new Товар()
                        {
                            Транспорт = line[0],
                            ПунктОтправки = line[1],
                            ПунктНазначения = line[2],
                            СтоимостьБилета = float.Parse(line[3]),
                        };
                        list.Add(tovar);
                    }
                }

            }
            return list;
        }
      
    }
}
