﻿using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataTier;
using LogicTier;
using Microsoft.Win32;

namespace PresentationTier;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    private Магазин магазин;
    public MainWindow()
    {
        InitializeComponent();
        магазин = new Магазин(new List<ТоварнаяПозиация>());
        this.DataContext = магазин;

    }

    private void btn_open_file_Click(object sender, RoutedEventArgs e)
    {
        List<Товар> товарыИзФайла = ВсеТовары.ПолучитьВсеТоварыИзФайла();

        if (товарыИзФайла.Count == 0)
        {
            MessageBox.Show("Нет товаров в файле!");
            return;
        }

        List<ТоварнаяПозиация> позиции = new List<ТоварнаяПозиация>();
        foreach (var t in товарыИзФайла)
        {
            позиции.Add(new ТоварнаяПозиация(t));
        }

        магазин = new Магазин(позиции);
        магазин.ОбновитьАналитику(); 
        this.DataContext = магазин;
    }
   
    private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (myComboBox.SelectedItem != null)
        {
            var selectedItem = (System.Windows.Controls.ComboBoxItem)myComboBox.SelectedItem;
            MessageBox.Show($"Выбрано: {selectedItem.Content}");
        }
    }

    private void btn_add_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            string откуда = PunktOtpravki.Text.Trim();
            string куда = PunktNaznachenia.Text.Trim();
            string транспорт = myComboBox.Text;
            string стоимостьStr = StoimostBileta.Text.Trim();

            // Проверка стоимости
            if (string.IsNullOrWhiteSpace(стоимостьStr))
            {
                MessageBox.Show("Введите стоимость билета.", "Ошибка");
                return;
            }

            if (!float.TryParse(стоимостьStr, out float стоимость) || стоимость < 0)
            {
                MessageBox.Show("Стоимость должна быть числом и не может быть отрицательной.", "Ошибка");
                return;
            }

            // Проверка пунктов: только буквы (русские и латинские), пробелы разрешены
            Regex толькоБуквы = new Regex(@"^[\p{L}\s\-]+$"); // \p{L} — любая буква

            if (string.IsNullOrWhiteSpace(откуда) || !толькоБуквы.IsMatch(откуда))
            {
                MessageBox.Show("Пункт отправки должен содержать только буквы.", "Ошибка");
                return;
            }

            if (string.IsNullOrWhiteSpace(куда) || !толькоБуквы.IsMatch(куда))
            {
                MessageBox.Show("Пункт назначения должен содержать только буквы.", "Ошибка");
                return;
            }

            var товар = new DataTier.Товар
            {
                Транспорт = транспорт,
                ПунктОтправки = откуда,
                ПунктНазначения = куда,
                СтоимостьБилета = стоимость
            };

            var позиция = new LogicTier.ТоварнаяПозиация(товар);
            var магазин = (LogicTier.Магазин)DataContext;
            магазин.СписокТоваров.Add(позиция);

            myComboBox.SelectedIndex = -1;
            PunktOtpravki.Clear();
            PunktNaznachenia.Clear();
            StoimostBileta.Clear();
        }
        catch (Exception ex)
        {
            MessageBox.Show("Ошибка при добавлении товара: " + ex.Message, "Ошибка");
        }
    }


    private void btn_delete_Click(object sender, RoutedEventArgs e)
    {
        if (MainList.SelectedItems.Count == 0)
        {
            MessageBox.Show("Пожалуйста, выделите элементы для удаления.", "Предупреждение");
            return;
        }

        var магазин = (LogicTier.Магазин)DataContext;
        var itemsToRemove = MainList.SelectedItems.Cast<LogicTier.ТоварнаяПозиация>().ToList();
        foreach (var item in itemsToRemove)
        {
            магазин.СписокТоваров.Remove(item);
        }

        магазин.ОбновитьАналитику();
    }

    private void btn_save_Click(object sender, RoutedEventArgs e)
    {
        var магазин = (LogicTier.Магазин)DataContext;

        // Преобразуем список товарных позиций в список товаров
        var товары = магазин.СписокТоваров
            .Select(позиция => new DataTier.Товар
            {
                Транспорт = позиция.Транспорт,
                ПунктОтправки = позиция.ПунктОтправки,
                ПунктНазначения = позиция.ПунктНазначения,
                СтоимостьБилета = позиция.СтоимостьБилета
            })
            .ToList();

        DataTier.ВсеТовары.СохранитьВсеТовары(товары);
    }
 }



