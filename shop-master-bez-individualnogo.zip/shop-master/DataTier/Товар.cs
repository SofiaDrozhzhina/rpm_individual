﻿

namespace DataTier
{
    public class Товар
    {
        public String Код {  get; set; }
        public string Наименование { get; set; }
        public float Цена { get; set; }
        public int Количество { get; set; }
        public string Описание { get; set; }
        public string ПредставлениеТовара => $"{Наименование} ({Количество} x {Цена}₽)";
    }

}
