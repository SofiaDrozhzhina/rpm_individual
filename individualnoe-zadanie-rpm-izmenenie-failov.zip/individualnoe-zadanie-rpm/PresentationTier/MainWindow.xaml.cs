﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataTier;
using LogicTier;
using Microsoft.Win32;

namespace PresentationTier;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    private Магазин магазин;
    public MainWindow()
    {
        InitializeComponent();
        
    }

    private void btn_open_file_Click(object sender, RoutedEventArgs e)
    {
        List<Товар> товарыИзФайла = ВсеТовары.ПолучитьВсеТоварыИзФайла();

        if (товарыИзФайла.Count == 0)
        {
            MessageBox.Show("Нет товаров в файле!");
            return;
        }

        List<ТоварнаяПозиация> позиции = new List<ТоварнаяПозиация>();
        foreach (var t in товарыИзФайла)
        {
            позиции.Add(new ТоварнаяПозиация(t));
        }

        магазин = new Магазин(позиции);
        this.DataContext = магазин;
    }
    private void BtnAddItem_Click(object sender, RoutedEventArgs e)
    {
        {
            {
                string line = TxtAdd.Text;

                // Если строка пуста, выводим сообщение об ошибке
                if (string.IsNullOrWhiteSpace(line))
                {
                    MessageBox.Show("Введите текст для добавления.");
                    return;
                }

                // Проверяем, была ли выбрана строка для редактирования
                if (MainList.SelectedItem != null)
                {
                    // Заменяем старую строку на новую в списке
                    int selectedIndex = MainList.SelectedIndex;
                    MainList.Items[selectedIndex] = line;
                    MessageBox.Show("Строка успешно обновлена.");
                }
                else
                {
                    // Если строки не редактируются, добавляем новую строку в список
                    MainList.Items.Add(line);

                }

                // Очищаем текстовое поле
                TxtAdd.Clear();
            }
        }
    }
}



